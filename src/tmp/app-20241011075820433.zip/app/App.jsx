import React, { useState, useEffect } from 'react';
import { getData, addData, deleteData, checkLogin, refreshTokenAPI } from './api';
import AddForm from './components/AddForm';
import SearchForm from './components/SearchForm';
import DataTable from './components/DataTable';
import LoginForm from './components/LoginForm';
import { jwtDecode } from 'jwt-decode'; // For token decoding
import './styles.css';

function App() {
  const [data, setData] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [mode, setMode] = useState('add');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  
  const [accessToken, setAccessToken] = useState(localStorage.getItem('accessToken'));
  const [refreshToken, setRefreshToken] = useState(localStorage.getItem('refreshToken'));
  const [user, setUser] = useState();

  useEffect(() => {
    if (isLoggedIn) {
      loadData();
    }
  }, [isLoggedIn]);

  const loadData = async (search = '') => {
    const responseData = await getData(search, accessToken);
    setData(responseData);
  };

  const handleAdd = async (newData) => {
    await addData(newData, accessToken);
    loadData();
  };

  const handleDelete = async (id) => {
    await deleteData(id, accessToken);
    loadData();
  };

  const handleSearch = (term) => {
    loadData(term);
    setSearchTerm(term);
  };

  const handleModeChange = (event) => {
    const selectedMode = event.target.value;
    setMode(selectedMode);
    setSearchTerm('');
  };

  const storeTokens = (newAccessToken, newRefreshToken) => {
    setAccessToken(newAccessToken);
    setRefreshToken(newRefreshToken);
    localStorage.setItem('accessToken', newAccessToken);
    localStorage.setItem('refreshToken', newRefreshToken);
    setIsLoggedIn(true);
  };

  const clearTokens = () => {
    setAccessToken(null);
    setRefreshToken(null);
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    setIsLoggedIn(false);
  };

  const handleLogin = async (status) => {

    try {
      const response = await checkLogin(status);
      setUser(status)
      if (response.status === 201) {
        storeTokens(response.data.access_token, response.data.refresh_token);
      } else {
        clearTokens();
      }
    } catch (error) {
      if (error.response && error.response.status === 401 && refreshToken) {
        try {
          const newTokens = await refreshTokenAPI(refreshToken);
          if (newTokens) {
            storeTokens(newTokens.access_token, newTokens.refresh_token);
            return handleLogin(user); // Retry login after refresh
          } else {
            clearTokens();
            throw error;
          }
        } catch (err) {
          clearTokens();
          throw err;
        }
      } else {
        clearTokens();
        throw error;
      }
    }
  };

  const isTokenExpired = async (token) => {
    try {
      const decodedToken = jwtDecode(token);
      const currentTime = Date.now() / 1000;
      if(decodedToken.exp > currentTime){
        try {
          const newTokens = await refreshTokenAPI(refreshToken);
          if (newTokens) {
            storeTokens(newTokens.access_token, newTokens.refresh_token);
            return handleLogin(user); // Retry login after refresh
          } else {
            clearTokens();
            throw error;
          }
        } catch (err) {
          clearTokens();
          throw err;
        }

      }else{
        return decodedToken.exp < currentTime;
      }
    } catch (error) {
      return true;
    }
  };

  const autoLogoutOnTokenExpiration = () => {
    console.log('====================================');
    console.log("isTokenExpired(accessToken) >> ",isTokenExpired(accessToken));
    console.log('====================================');
    if (isTokenExpired(accessToken)) {
      clearTokens(); // If the access token is expired, log the user out
    }
  };

  // Check every 1 minute if token is expired
  useEffect(() => {
    const interval = setInterval(() => {
      if (accessToken) {
        autoLogoutOnTokenExpiration();
      }
    }, 60000); // Check every 60 seconds (1 minute)

    return () => clearInterval(interval); // Clean up interval on unmount
  }, [accessToken]);

  return (
    <div className="container">
      <h1>API Management</h1>
      {!isLoggedIn ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        <>
          <button onClick={clearTokens}>Logout</button>
          <select value={mode} onChange={handleModeChange}>
            <option value="add">Add Data</option>
            <option value="search">Search Data</option>
          </select>

          {mode === 'add' ? (
            <AddForm onAdd={handleAdd} />
          ) : (
            <SearchForm onSearch={handleSearch} />
          )}

          <DataTable data={data} onDelete={handleDelete} />
        </>
      )}
    </div>
  );
}

export default App;
